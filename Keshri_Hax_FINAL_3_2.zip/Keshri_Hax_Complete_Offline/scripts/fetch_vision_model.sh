#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/app/src/main/assets"
URL="https://huggingface.co/NAKSTStudio/yolov8m-chess-piece-detection/resolve/main/best_f16.tflite?download=true"
curl -L --fail --retry 3 "$URL" -o "$ROOT/app/src/main/assets/chess_detector.tflite"
echo "Vision model downloaded."
