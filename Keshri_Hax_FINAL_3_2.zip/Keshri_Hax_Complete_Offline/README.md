# Keshri Hax 3.1 — Android source project

This is an Android Studio/Gradle source project for offline chess position analysis. It includes a dark animated launcher, side selection, Android screen-capture overlay service, physical-board camera mode, FEN validation/building, Stockfish UCI integration, and a GitHub Actions APK workflow.

## Important truth about detection

- Screen capture can only inspect pixels on the phone screen; it cannot see a physical board in the room.
- Physical-board mode uses a guided center crop and a TFLite piece detector. If the model download is unavailable or the model's tensor layout differs, the app will report a recognition/model error rather than inventing a move.
- Reliable physical-board recognition needs calibration and a compatible trained model. This project is not claimed to be fully device-tested or production-validated until a GitHub Actions build and on-device test pass.
- Intended for offline boards, puzzles, and analysis of your own games; not for real-time assistance in live rated online matches.

## Build with GitHub Actions (recommended from a phone)

1. Upload/replace the project files in your repository and commit them to `main`.
2. Open **Actions → Build Keshri Hax APK → Run workflow** (a push to `main` also starts it).
3. Wait for the workflow to finish. Open the run, then download artifact `keshri-hax-debug-apk`.
4. Install the APK on your Android device and grant overlay/capture/camera permissions only for the modes you use.

The workflow installs JDK 17, Android SDK platform 35, build-tools 35.0.0, and Gradle 8.7. No local `ANDROID_HOME` is required for this CI workflow.

## Install project into an existing Codespace

Upload this ZIP into the repository root first. Then run the following from the repository root, changing the ZIP filename if needed:

```bash
unzip -o Keshri_Hax_FINAL_3_1.zip -d /tmp/keshri-hax-final
cp -a /tmp/keshri-hax-final/Keshri_Hax_Complete_Offline/. .
git status --short
```

Review the changed files, then commit using the Git UI. Do not run `git reset --hard` or delete the repository.

## Licences

Stockfish is GPLv3; its source/license must be made available when redistributing a binary. The referenced third-party vision model may have its own licence/attribution requirements; verify the model card before distributing an APK that includes it. Do not distribute a model or binary unless its licence permits it.
