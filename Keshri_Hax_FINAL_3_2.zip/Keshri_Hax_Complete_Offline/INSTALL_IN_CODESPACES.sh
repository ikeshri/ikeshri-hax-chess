#!/usr/bin/env bash
set -euo pipefail
ZIP="${1:-Keshri_Hax_FINAL_3_1.zip}"
if [[ ! -f "$ZIP" ]]; then echo "ZIP not found: $ZIP. Upload it into the repo root first."; exit 2; fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ZIP" -d "$TMP"
ROOT="$TMP/Keshri_Hax_Complete_Offline"
if [[ ! -f "$ROOT/settings.gradle.kts" || ! -f "$ROOT/app/build.gradle.kts" ]]; then echo "ZIP layout not recognized; no files copied."; exit 3; fi
cp -a "$ROOT/." .
echo "Project files copied into $(pwd). Review with: git status --short"
echo "Next: commit changes, then use GitHub Actions → Build Keshri Hax APK."
