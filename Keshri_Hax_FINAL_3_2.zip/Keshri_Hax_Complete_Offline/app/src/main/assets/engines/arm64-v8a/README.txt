This folder is populated by scripts/build_stockfish.sh during the GitHub Actions build.
Do not rename the final binary: stockfish
