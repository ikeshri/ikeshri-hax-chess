package com.keshri.hax

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Camera pipeline for a guided physical/offline board. It reports an explicit calibration/model error
 * instead of inventing a move when the board or model cannot be recognized. */
class OfflineBoardAnalyzer(
    context: Context,
    private val side: String,
    private val onStatus: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private val appContext = context.applicationContext
    private val detector = ChessDetector(appContext)
    private val engine = Engine(appContext)
    private val busy = AtomicBoolean(false)
    @Volatile private var lastFen = ""
    @Volatile private var lastAnalysisAt = 0L

    override fun analyze(image: ImageProxy) {
        if (!busy.compareAndSet(false, true)) { image.close(); return }
        try {
            val bitmap = imageToBitmap(image) ?: run { onStatus("CAMERA FRAME ERROR — RETRY"); return }
            val board = BoardVision.detect(bitmap)
            if (board == null) { onStatus("ALIGN THE FULL 8×8 BOARD INSIDE THE GUIDE"); bitmap.recycle(); return }
            val detections = detector.detect(board.board)
            val fen = detector.toFen(detections, side.equals("WHITE", true))
            val now = System.currentTimeMillis()
            if (fen == null) {
                onStatus("BOARD FOUND • PIECES NOT VALIDATED. Keep all 64 squares visible and improve lighting.")
            } else if (fen != lastFen || now - lastAnalysisAt > 5000) {
                lastFen = fen
                lastAnalysisAt = now
                onStatus("BOARD VALID • ${detections.size} DETECTIONS\nFEN: $fen\nANALYZING WITH STOCKFISH…")
                val result = engine.analyze(fen, 16)
                onStatus("OFFLINE BOARD ANALYSIS\nBEST: ${result.bestMove}\nEVAL: ${result.evaluation}\nDEPTH: ${result.depth}  NODES: ${result.nodes}\nPV: ${result.pv}\nFEN: ${result.fen}\n${result.status}")
            } else {
                onStatus("BOARD TRACKED • FEN unchanged\nBEST: analysing/last result\nHold the board steady for refresh.")
            }
            board.board.recycle(); bitmap.recycle()
        } catch (t: Throwable) {
            onStatus("SCAN ERROR: ${t.message ?: "unknown"}")
        } finally { image.close(); busy.set(false) }
    }

    private fun imageToBitmap(image: ImageProxy): Bitmap? {
        val y = image.planes[0].buffer
        val u = image.planes[1].buffer
        val v = image.planes[2].buffer
        val ySize = y.remaining(); val uSize = u.remaining(); val vSize = v.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        y.get(nv21, 0, ySize)
        // NV21 chroma order is V then U; account for CameraX plane strides.
        val w = image.width; val h = image.height
        val chromaW = w / 2; val chromaH = h / 2
        val up = image.planes[1]; val vp = image.planes[2]
        var out = ySize
        for (row in 0 until chromaH) for (col in 0 until chromaW) {
            val vi = row * vp.rowStride + col * vp.pixelStride
            val ui = row * up.rowStride + col * up.pixelStride
            nv21[out++] = v.get(vi); nv21[out++] = u.get(ui)
        }
        val yuv = YuvImage(nv21, android.graphics.ImageFormat.NV21, w, h, null)
        val stream = ByteArrayOutputStream()
        if (!yuv.compressToJpeg(Rect(0, 0, w, h), 78, stream)) return null
        return BitmapFactory.decodeByteArray(stream.toByteArray(), 0, stream.size())
    }

    fun close() { engine.stop() }
}
