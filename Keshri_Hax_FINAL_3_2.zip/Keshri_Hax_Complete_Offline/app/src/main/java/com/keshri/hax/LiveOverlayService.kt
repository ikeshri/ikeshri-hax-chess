package com.keshri.hax

import android.app.*
import android.content.*
import android.graphics.*
import android.media.projection.MediaProjectionManager
import android.media.ImageReader
import android.hardware.display.DisplayManager
import android.os.*
import android.view.*
import android.widget.*

class LiveOverlayService: Service(){
    private lateinit var wm:WindowManager
    private lateinit var panel:LinearLayout
    private var running=true
    private lateinit var statusView:TextView
    private var projection:android.media.projection.MediaProjection?=null
    private var virtualDisplay:android.hardware.display.VirtualDisplay?=null
    private var reader:ImageReader?=null
    private var analyzer:CaptureAnalyzer?=null
    private lateinit var resultView:TextView
    private val handler=Handler(Looper.getMainLooper())
    private var side="WHITE"

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        side=intent?.getStringExtra("SIDE")?:"WHITE"
        createNotification()
        showOverlay()
        val code=intent?.getIntExtra("RESULT_CODE",0)?:0
        val data=intent?.getParcelableExtra<Intent>("DATA_INTENT")
        if(data!=null && code!=0)startCapture(code,data)
        return START_NOT_STICKY
    }
    private fun createNotification(){
        val ch="keshri_hax"
        if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch,"Keshri Hax",NotificationManager.IMPORTANCE_LOW))
        val n=Notification.Builder(this,ch).setSmallIcon(android.R.drawable.ic_menu_search).setContentTitle("Keshri Hax Analyzer").setContentText("Offline analysis panel active").build()
        startForeground(41,n)
    }
    private fun showOverlay(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16);setBackgroundColor(Color.argb(238,9,14,21))}
        val title=TextView(this).apply{text="KESHRI HAX  •  OFFLINE";setTextColor(Color.CYAN);textSize=14f}
        panel.addView(title)
        statusView=TextView(this).apply{text="STARTING SCAN…  |  SIDE: $side";setTextColor(Color.WHITE);textSize=11f}
        panel.addView(statusView)
        resultView=TextView(this).apply{text="BOARD  —\nPIECES  —\nFEN     —\nEVAL    —\nBEST    —\nDEPTH   —\nPV      —";setTextColor(Color.LTGRAY);textSize=12f}
        panel.addView(resultView)
        val row=LinearLayout(this)
        fun b(t:String,click:()->Unit)=Button(this).apply{text=t;textSize=9f;setOnClickListener{click()}}
        row.addView(b("RESCAN"){analyzer?.rescan();statusView.text="RESCAN REQUESTED • LOOKING FOR BOARD…"})
        row.addView(b("PAUSE / RESUME"){running=!running;analyzer?.setPaused(!running);statusView.text=if(running)"SCANNING RESUMED" else "ANALYSIS PAUSED"})
        row.addView(b("STOP"){stopSelf()})
        panel.addView(row)
        val p=WindowManager.LayoutParams(360,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=10;y=110}
        wm.addView(panel,p)
        // Current build intentionally does not fabricate a board result. It reports readiness until a real detector/model supplies FEN.
        statusView.postDelayed({if(running && analyzer==null)statusView.text="READY • START SCREEN CAPTURE TO ANALYZE YOUR OFFLINE BOARD"},1000)
    }
    private fun startCapture(code:Int,data:Intent){
        try{
            val mpm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection=mpm.getMediaProjection(code,data)
            val dm=getSystemService(DISPLAY_SERVICE) as DisplayManager
            val display=dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
            val metrics=resources.displayMetrics
            val w=metrics.widthPixels.coerceAtMost(1440); val h=metrics.heightPixels.coerceAtMost(2560)
            reader=ImageReader.newInstance(w,h,android.graphics.PixelFormat.RGBA_8888,2)
            virtualDisplay=projection?.createVirtualDisplay("KeshriHaxCapture",w,h,metrics.densityDpi,android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,null)
            analyzer=CaptureAnalyzer(this,ChessDetector(this),Engine(this)).also{it.attach(reader!!)}
        }catch(_:Throwable){ publishStatus("CAPTURE ERROR — RESTART ANALYSIS") }
    }
    fun publishStatus(s:String){if(::resultView.isInitialized)resultView.post{resultView.text=s}; if(::statusView.isInitialized)statusView.post{statusView.text=s.lineSequence().firstOrNull() ?: "ANALYZING"}}
    fun publishResult(r:AnalysisResult,pieces:Int){if(::resultView.isInitialized)resultView.post{resultView.text="BOARD  OK\nPIECES  $pieces\nFEN     ${r.fen}\nEVAL    ${r.evaluation}\nBEST    ${r.bestMove}\nDEPTH   ${r.depth}\nNODES   ${r.nodes}\nPV      ${r.pv}"}}
    override fun onDestroy(){handler.removeCallbacksAndMessages(null);analyzer?.stop();reader?.close();virtualDisplay?.release();projection?.stop();if(::panel.isInitialized)try{wm.removeView(panel)}catch(_:Throwable){};super.onDestroy()}
    override fun onBind(intent:Intent?)=null
}
