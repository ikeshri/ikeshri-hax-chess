package com.keshri.hax

import android.content.Context
import java.io.File

object EngineInstaller {
    fun install(context:Context):File? {
        val out=File(context.filesDir,"stockfish"); if(out.exists() && out.canExecute())return out
        return try{
            context.assets.open("engines/arm64-v8a/stockfish").use{input->out.outputStream().use{input.copyTo(it)}}
            out.setExecutable(true,true); out
        }catch(_:Throwable){null}
    }
}
