package com.keshri.hax

import android.graphics.Bitmap
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.atomic.AtomicBoolean

class CaptureAnalyzer(private val service: LiveOverlayService, private val detector: ChessDetector, private val engine: Engine) {
    private val busy = AtomicBoolean(false)
    private val thread = HandlerThread("keshri-frame").apply { start() }
    private val handler = Handler(thread.looper)
    @Volatile private var paused = false
    @Volatile private var forceRescan = true
    @Volatile private var lastFen = ""
    @Volatile private var lastAnalysisAt = 0L

    fun attach(reader: ImageReader) {
        reader.setOnImageAvailableListener({ r ->
            if (paused || !busy.compareAndSet(false, true)) {
                try { r.acquireLatestImage()?.close() } catch (_: Throwable) {}
                return@setOnImageAvailableListener
            }
            handler.post {
                try { analyze(r) } catch (t: Throwable) { service.publishStatus("SCAN ERROR • ${t.message ?: "unknown"}") }
                finally { busy.set(false) }
            }
        }, handler)
    }

    fun setPaused(value: Boolean) { paused = value; if (!value) forceRescan = true }
    fun rescan() { lastFen = ""; forceRescan = true }

    private fun analyze(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        var bitmap: Bitmap? = null
        var boardBitmap: Bitmap? = null
        try {
            val plane = image.planes[0]
            val w = image.width; val h = image.height
            val buffer = plane.buffer; val row = plane.rowStride; val pixel = plane.pixelStride
            bitmap = Bitmap.createBitmap(w + (row - pixel * w) / pixel, h, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val board = BoardVision.detect(bitmap)
            if (board == null) {
                service.publishStatus("BOARD NOT FOUND\nKeep the full 8×8 offline board visible and press RESCAN.")
                return
            }
            boardBitmap = board.board
            val detections = detector.detect(boardBitmap)
            val fen = detector.toFen(detections, true)
            if (fen == null) {
                service.publishStatus("BOARD FOUND • PIECES NOT VALIDATED\nImprove lighting, keep all squares visible, then RESCAN.")
                return
            }
            val now = System.currentTimeMillis()
            if (forceRescan || fen != lastFen || now - lastAnalysisAt > 5000) {
                forceRescan = false; lastFen = fen; lastAnalysisAt = now
                service.publishStatus("VALID POSITION • ANALYZING STOCKFISH…\nFEN: $fen")
                val result = engine.analyze(fen, 16)
                service.publishResult(result, detections.size)
            } else service.publishStatus("POSITION TRACKED • FEN unchanged\nPress RESCAN after a move.")
        } finally {
            try { boardBitmap?.recycle() } catch (_: Throwable) {}
            try { bitmap?.recycle() } catch (_: Throwable) {}
            image.close()
        }
    }

    fun stop() { thread.quitSafely(); engine.stop() }
}
