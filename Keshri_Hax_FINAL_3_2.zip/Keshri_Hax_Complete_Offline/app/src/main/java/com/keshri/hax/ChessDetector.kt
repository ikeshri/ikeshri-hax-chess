package com.keshri.hax

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

class ChessDetector(context: Context) {
    data class Detection(val cls:Int,val score:Float,val cx:Float,val cy:Float,val w:Float,val h:Float)
    private val interpreter: Interpreter? = load(context)
    private val names = arrayOf("board","white_king","white_queen","white_rook","white_bishop","white_knight","white_pawn","black_king","black_queen","black_rook","black_bishop","black_knight","black_pawn")

    private fun load(context:Context):Interpreter? = try {
        val afd=context.assets.openFd("chess_detector.tflite")
        val input=FileInputStream(afd.fileDescriptor)
        val mapped=input.channel.map(FileChannel.MapMode.READ_ONLY,afd.startOffset,afd.declaredLength)
        Interpreter(mapped,Interpreter.Options().apply{setNumThreads(4)})
    }catch(_:Throwable){null}

    fun detect(source:Bitmap):List<Detection> {
        val t=interpreter ?: return emptyList()
        val img=Bitmap.createScaledBitmap(source,640,640,true)
        val input=ByteBuffer.allocateDirect(1*640*640*3*4).order(ByteOrder.nativeOrder())
        val px=IntArray(640*640); img.getPixels(px,0,640,0,0,640,640)
        for(p in px){input.putFloat(((p shr 16) and 255)/255f);input.putFloat(((p shr 8) and 255)/255f);input.putFloat((p and 255)/255f)}
        input.rewind()
        val out=Array(1){Array(17){FloatArray(8400)}}
        try{t.run(input,out)}catch(_:Throwable){return emptyList()}
        val list=ArrayList<Detection>()
        for(i in 0 until 8400){
            var best=-1;var score=0f
            for(c in 0 until 13){val s=out[0][4+c][i];if(s>score){score=s;best=c}}
            if(best>=0 && score>.28f){
                val cx=out[0][0][i]/640f;val cy=out[0][1][i]/640f;val w=out[0][2][i]/640f;val h=out[0][3][i]/640f
                list.add(Detection(best,score,cx,cy,w,h))
            }
        }
        return nms(list)
    }

    fun toFen(detections:List<Detection>, whiteToMove:Boolean=true):String? {
        val board=Array(8){CharArray(8){'.'}}
        val best=HashMap<Pair<Int,Int>,Detection>()
        for(d in detections){if(d.cls==0)continue;val col=(d.cx*8).toInt().coerceIn(0,7);val row=(d.cy*8).toInt().coerceIn(0,7);val k=row to col;if(d.score>(best[k]?.score?:0f))best[k]=d}
        val map=mapOf(1 to 'K',2 to 'Q',3 to 'R',4 to 'B',5 to 'N',6 to 'P',7 to 'k',8 to 'q',9 to 'r',10 to 'b',11 to 'n',12 to 'p')
        for((k,d) in best)board[k.first][k.second]=map[d.cls]?:'.'
        if(!PositionValidator.valid(board))return null
        return FenBuilder.fromBoard(board,whiteToMove)
    }

    private fun nms(input:List<Detection>):List<Detection>{
        val out=ArrayList<Detection>()
        for(d in input.sortedByDescending{it.score}){
            if(out.none{sameClass(it,d)&&iou(it,d)>.45f})out.add(d)
            if(out.size>=64)break
        }
        return out
    }
    private fun sameClass(a:Detection,b:Detection)=a.cls==b.cls
    private fun iou(a:Detection,b:Detection):Float{val ax1=a.cx-a.w/2;val ay1=a.cy-a.h/2;val ax2=a.cx+a.w/2;val ay2=a.cy+a.h/2;val bx1=b.cx-b.w/2;val by1=b.cy-b.h/2;val bx2=b.cx+b.w/2;val by2=b.cy+b.h/2;val iw=max(0f,min(ax2,bx2)-max(ax1,bx1));val ih=max(0f,min(ay2,by2)-max(ay1,by1));val inter=iw*ih;return inter/(a.w*a.h+b.w*b.h-inter+1e-6f)}
}
