package com.keshri.hax

import android.content.Context
import java.io.*
import java.util.concurrent.TimeUnit

class Engine(private val context:Context){
    private var process:Process?=null
    private var writer:BufferedWriter?=null
    private var reader:BufferedReader?=null
    fun start():Boolean = try {
        val f=EngineInstaller.install(context) ?: return false
        process=ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
        writer=process!!.outputStream.bufferedWriter(); reader=process!!.inputStream.bufferedReader()
        send("uci"); waitFor("uciok",4000); send("isready"); waitFor("readyok",4000); true
    } catch(_:Throwable){false}
    fun analyze(fen:String, depth:Int=16):AnalysisResult{
        if(process==null && !start()) return AnalysisResult("—","—",0,0,"Engine binary missing",0,fen,"ENGINE NOT INSTALLED")
        return try{
            send("position fen $fen"); send("go depth $depth")
            var best="—"; var score="—"; var d=0; var nodes=0L; var pv=""
            val end=System.currentTimeMillis()+12000
            while(System.currentTimeMillis()<end){
                val line=readLine(250) ?: continue
                if(line.startsWith("info ")){
                    Regex("depth (\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()?.let{d=it}
                    Regex("nodes (\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull()?.let{nodes=it}
                    Regex("score cp (-?\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()?.let{score=String.format("%+.2f",it/100.0)}
                    Regex("pv (.+)").find(line)?.groupValues?.get(1)?.let{pv=it}
                }
                if(line.startsWith("bestmove ")){best=line.removePrefix("bestmove ").substringBefore(' ');break}
            }
            AnalysisResult(best,score,d,nodes,pv,if(d>0)92 else 35,fen,"ANALYZED")
        }catch(e:Throwable){AnalysisResult("—","—",0,0,e.message?:"Engine error",0,fen,"ENGINE ERROR")}
    }
    private fun send(s:String){writer?.apply{write(s);newLine();flush()}}
    private fun waitFor(token:String,ms:Long){val end=System.currentTimeMillis()+ms;while(System.currentTimeMillis()<end){val l=reader?.readLine()?:break;if(l.contains(token))break}}
    private fun readLine(ms:Long):String?{val end=System.currentTimeMillis()+ms;while(System.currentTimeMillis()<end){if(reader?.ready()==true)return reader!!.readLine();Thread.sleep(10)};return null}
    fun stop(){try{send("quit");process?.destroy();process?.waitFor(1,TimeUnit.SECONDS)}catch(_:Throwable){};process=null}
}
