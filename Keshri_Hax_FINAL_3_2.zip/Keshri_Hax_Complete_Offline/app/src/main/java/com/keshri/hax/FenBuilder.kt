package com.keshri.hax

object FenBuilder {
    fun fromBoard(board: Array<CharArray>, whiteToMove:Boolean):String {
        val rows=board.joinToString("/") { row ->
            var out=""; var empty=0
            for(c in row){ if(c=='.') empty++ else {if(empty>0){out+=empty;empty=0};out+=c} }
            if(empty>0)out+=empty; out
        }
        return "$rows ${if(whiteToMove)"w" else "b"} - - 0 1"
    }
    fun start():String="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
}
