package com.keshri.hax

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

class AnimatedBackgroundView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val stars = List(80) { Pair(Math.random().toFloat(), Math.random().toFloat()) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(4, 7, 12))
        val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f
        for (i in 0..18) {
            val y = h * (0.18f + i / 24f)
            paint.color = Color.argb(22, 70, 225, 255)
            canvas.drawLine(0f, y + sin(phase + i) * 10f, w, y, paint)
        }
        paint.style = Paint.Style.FILL
        stars.forEachIndexed { i, p ->
            val a = (40 + 40 * (0.5 + 0.5 * sin(phase * 2 + i))).toInt()
            paint.color = Color.argb(a, 100, 220, 255)
            canvas.drawCircle(p.first * w, p.second * h, 1.2f, paint)
        }
        val cx = w * .5f; val cy = h * .43f
        for (r in floatArrayOf(.18f,.26f,.34f)) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            paint.color = Color.argb(30, 160, 100, 255)
            canvas.drawCircle(cx, cy, min(w,h)*r, paint)
        }
        paint.style = Paint.Style.FILL
        phase += .018f
        postInvalidateOnAnimation()
    }
}
