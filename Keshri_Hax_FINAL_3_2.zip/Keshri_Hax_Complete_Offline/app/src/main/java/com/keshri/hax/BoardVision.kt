package com.keshri.hax

import android.graphics.Bitmap
import kotlin.math.max

object BoardVision {
    data class Detection(val board: Bitmap, val confidence: Int, val message: String)

    /** Guided-center detector: works reliably when the board is aligned to the scan frame. */
    fun detect(source: Bitmap): Detection? {
        if (source.width < 160 || source.height < 160) return null
        val side = max(160, (minOf(source.width, source.height) * .82f).toInt())
        val left=(source.width-side)/2
        val top=(source.height-side)/2
        return Detection(Bitmap.createBitmap(source,left,top,side,side),72,"GUIDED BOARD CROP")
    }

    fun split8x8(board: Bitmap): List<Bitmap> {
        val s=board.width/8
        return (0 until 8).flatMap { r -> (0 until 8).map { c -> Bitmap.createBitmap(board,c*s,r*s,s,s) } }
    }
}
