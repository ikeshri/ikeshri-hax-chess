package com.keshri.hax

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class CameraActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private var analyzer: OfflineBoardAnalyzer? = null
    private val side by lazy { intent.getStringExtra("SIDE") ?: "WHITE" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        val root = FrameLayout(this)
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))
        status = TextView(this).apply {
            text = "KESHRI HAX • PHYSICAL BOARD SCAN\nAlign the full 8×8 board in the centre.\nUse only offline boards, puzzles or your own games."
            textSize = 13f; setTextColor(Color.WHITE); setPadding(22, 18, 22, 18)
            setBackgroundColor(0xD9101724.toInt()); gravity = Gravity.CENTER_VERTICAL
        }
        val lp = FrameLayout.LayoutParams(-1, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        lp.setMargins(16, 35, 16, 0)
        root.addView(status, lp)
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 44)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else status.text = "CAMERA PERMISSION REQUIRED TO SCAN A PHYSICAL BOARD"
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val p = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val a = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analyzer = OfflineBoardAnalyzer(this, side) { message -> runOnUiThread { status.text = message } }
                a.setAnalyzer(executor, analyzer!!)
                provider.unbindAll(); provider.bindToLifecycle(this, androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA, p, a)
            } catch (t: Throwable) { status.text = "CAMERA START ERROR: ${t.message ?: "unknown"}" }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() { analyzer?.close(); executor.shutdown(); super.onDestroy() }
}
