package com.keshri.hax

object PositionValidator {
    private val pieces="PNBRQKpnbrqk."
    fun valid(board:Array<CharArray>):Boolean {
        if(board.size!=8 || board.any{it.size!=8}) return false
        val all=board.flatMap{it.asList()}
        return all.all{it in pieces} && all.count{it=='K'}==1 && all.count{it=='k'}==1
    }
}
