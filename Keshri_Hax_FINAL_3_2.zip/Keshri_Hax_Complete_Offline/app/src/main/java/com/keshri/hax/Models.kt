package com.keshri.hax

data class AnalysisResult(
    val bestMove: String,
    val evaluation: String,
    val depth: Int,
    val nodes: Long,
    val pv: String,
    val confidence: Int,
    val fen: String,
    val status: String
)

data class BoardFrame(
    val bitmap: android.graphics.Bitmap,
    val source: String,
    val confidence: Int
)
