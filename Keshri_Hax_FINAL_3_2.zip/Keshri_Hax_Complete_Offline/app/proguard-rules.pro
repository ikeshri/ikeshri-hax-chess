# Keshri Hax: keep UCI engine/process and TFLite integration simple for the first production build.
-keep class org.tensorflow.** { *; }
-dontwarn org.tensorflow.**
