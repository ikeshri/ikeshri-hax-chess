# Keshri Hax 3.2 — feature/readiness audit

## Included in source
- Dark animated launcher, White/Black selection and start/stop actions.
- MediaProjection capture service and floating overlay panel.
- Physical-board camera entry using CameraX.
- TFLite model integration, board/FEN validation path and Stockfish UCI adapter.
- RESCAN and PAUSE/RESUME now signal the capture analyzer instead of only changing label text.
- GitHub Actions builds Java 17 + Android SDK 35, Stockfish arm64 and the vision model, then uploads the APK artifact.

## Important honesty notes
- This is an integrated source candidate, not a device-certified final release. A green CI build does not prove that every camera angle, board color, lighting condition or Android OEM overlay policy works.
- The vision model download is now a required CI step: if download/model file validation fails, the workflow fails instead of quietly producing an APK without the model.
- Model output tensor/layout and board crop assumptions must be tested against the downloaded model and real device images. If the model's exported tensor format differs, the detector adapter needs adjustment.
- Screen capture can only analyze pixels on the phone screen. A real physical board must use Camera mode.
- Use for offline boards, puzzles, and analysis of games you control; not for real-time assistance in live rated online matches.

## Build
Use GitHub Actions → Build Keshri Hax APK → Run workflow. On success, download `keshri-hax-debug-apk`. The APK path in the build environment is `app/build/outputs/apk/debug/app-debug.apk`.
