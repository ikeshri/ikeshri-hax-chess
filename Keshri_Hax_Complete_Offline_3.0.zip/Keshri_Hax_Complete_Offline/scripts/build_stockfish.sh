#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$ROOT/.stockfish-src"
if [ ! -d "$WORK/.git" ]; then
  git clone --depth 1 --branch sf_19 https://github.com/official-stockfish/Stockfish.git "$WORK"
fi
# Requires Android NDK r27c+ in PATH. GitHub Actions installs one automatically.
make -C "$WORK/src" -j2 build ARCH=armv8 COMP=ndk
mkdir -p "$ROOT/app/src/main/assets/engines/arm64-v8a"
cp "$WORK/src/stockfish" "$ROOT/app/src/main/assets/engines/arm64-v8a/stockfish"
chmod 755 "$ROOT/app/src/main/assets/engines/arm64-v8a/stockfish"
echo "Stockfish copied into app assets."
