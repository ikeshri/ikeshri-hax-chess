# Keshri Hax 3.0 — Offline Chess Analyzer

A phone-first Android project with a premium animated launcher, overlay panel, screen-capture permission flow, physical-board camera entry point, board/FEN pipeline interfaces, and UCI Stockfish integration.

## Important
This build is for offline boards, puzzles, and analysis of games you control. It does not include an online-game cheating workflow.

### What is included
- Android 14–16 compatible target setup (compile/target 35)
- Premium animated cyber background without external image assets
- White/Black selection
- Overlay permission + Android MediaProjection flow
- Floating analysis panel with RESCAN / PAUSE / STOP
- Physical board camera mode using CameraX
- Board crop/perspective pipeline entry point and FEN/position validator
- UCI Stockfish adapter
- GitHub Actions build that installs Gradle 8.7 and JDK 17
- Optional automatic Stockfish arm64 build from the official Stockfish source

### Vision model note
A truly reliable piece recognizer requires a trained 13-class chess-piece model matched to the camera/board style. The project therefore does not pretend that a dummy model is accurate. The pipeline interfaces are ready for the model, while the UI reports calibration/model readiness instead of inventing moves.

## Codespaces / GitHub Actions
The included workflow uses `gradle/actions/setup-gradle` with Gradle 8.7 and Java 17. It also builds an arm64 Stockfish binary from the official source and copies it into app assets before assembling the APK.

If you are using Codespaces and the repository contains this project:

```bash
chmod +x scripts/build_stockfish.sh
./scripts/build_stockfish.sh
```

Then build:

```bash
gradle :app:assembleDebug --no-daemon --stacktrace
```

The APK will be at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### If `gradle` is not installed in Codespaces
Use the GitHub Actions workflow instead, or run:

```bash
curl -sSfL https://services.gradle.org/distributions/gradle-8.7-bin.zip -o /tmp/gradle.zip
mkdir -p $HOME/gradle
unzip -q /tmp/gradle.zip -d $HOME/gradle
echo 'export PATH="$HOME/gradle/gradle-8.7/bin:$PATH"' >> ~/.bashrc
export PATH="$HOME/gradle/gradle-8.7/bin:$PATH"
gradle :app:assembleDebug --no-daemon --stacktrace
```

## Stockfish license
Stockfish is GPLv3. If you distribute an APK containing the engine, keep the corresponding license/source notices. The official project is at https://github.com/official-stockfish/Stockfish.

### Vision model used by the build
The CI workflow downloads the `best_f16.tflite` chess board/piece detector from the public NAKSTStudio model repository and places it at `app/src/main/assets/chess_detector.tflite`. The model is 51.9 MB and is licensed AGPL-3.0; review and comply with that license before redistributing the APK. The model advertises 13 classes including the board and the 12 piece colors/types. It is intended for real-time chess-piece detection and offline Stockfish analysis.
