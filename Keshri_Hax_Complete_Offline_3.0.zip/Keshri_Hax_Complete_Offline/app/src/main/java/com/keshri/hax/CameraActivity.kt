package com.keshri.hax

import android.Manifest
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import java.util.concurrent.Executors

class CameraActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private val executor = Executors.newSingleThreadExecutor()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preview = PreviewView(this)
        val root = FrameLayout(this)
        root.addView(preview, FrameLayout.LayoutParams(-1,-1))
        val label = TextView(this).apply { text="PHYSICAL BOARD SCAN\nAlign the full 8×8 board inside the guide.\nAnalysis is for offline/self-game/puzzle use."; textSize=14f; setTextColor(android.graphics.Color.WHITE); setPadding(25,50,25,20) }
        root.addView(label)
        setContentView(root)
        requestPermissions(arrayOf(Manifest.permission.CAMERA), 44)
        startCamera()
    }
    private fun startCamera(){
        val future=ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider=future.get()
            val p=Preview.Builder().build().also{it.setSurfaceProvider(preview.surfaceProvider)}
            val a=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            a.setAnalyzer(executor, OfflineBoardAnalyzer())
            provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,p,a)
        }, mainExecutor)
    }
    override fun onDestroy(){super.onDestroy();executor.shutdown()}
}
