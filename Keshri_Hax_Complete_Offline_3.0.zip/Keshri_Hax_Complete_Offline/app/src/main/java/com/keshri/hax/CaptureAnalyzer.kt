package com.keshri.hax

import android.graphics.Bitmap
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.atomic.AtomicBoolean

class CaptureAnalyzer(private val service:LiveOverlayService, private val detector:ChessDetector, private val engine:Engine){
    private val busy=AtomicBoolean(false)
    private val thread=HandlerThread("keshri-frame").apply{start()}
    private val handler=Handler(thread.looper)
    fun attach(reader:ImageReader){reader.setOnImageAvailableListener({r->if(!busy.compareAndSet(false,true))return@setOnImageAvailableListener;handler.post{try{analyze(r)}finally{busy.set(false)}}},handler)}
    private fun analyze(reader:ImageReader){
        val image=reader.acquireLatestImage()?:return
        try{
            val plane=image.planes[0];val w=image.width;val h=image.height;val buffer=plane.buffer;val row=plane.rowStride;val pixel=plane.pixelStride
            val bmp=Bitmap.createBitmap(w+(row-pixel*w)/pixel,h,Bitmap.Config.ARGB_8888);bmp.copyPixelsFromBuffer(buffer)
            val crop=BoardVision.detect(bmp)?.board?:return
            val det=detector.detect(crop)
            val fen=detector.toFen(det,true)?:return
            val result=engine.analyze(fen,16)
            service.publishResult(result,det.size)
            bmp.recycle()
        }catch(_:Throwable){}finally{image.close()}
    }
    fun stop(){thread.quitSafely()}
}
