package com.keshri.hax

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var status: TextView
    private var selectedSide = "WHITE"

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val captureData = result.data
        if (result.resultCode == Activity.RESULT_OK && captureData != null) {
            val i = Intent(this, LiveOverlayService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA_INTENT", captureData)
                putExtra("SIDE", selectedSide)
            }
            startForegroundService(i)
            status.text = "● ANALYZER ARMED  •  OPEN YOUR OFFLINE BOARD"
        } else status.text = "● CAPTURE CANCELLED"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.addView(AnimatedBackgroundView(this), FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this).apply { setPadding(28, 45, 28, 35) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(-1,-1))

        val title = TextView(this).apply { text="KESHRI HAX"; textSize=34f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; typeface=android.graphics.Typeface.DEFAULT_BOLD }
        box.addView(title, lp(0,18))
        val sub = TextView(this).apply { text="OFFLINE CHESS ANALYSIS CORE  •  v3.0"; textSize=12f; setTextColor(Color.rgb(90,220,255)); gravity=Gravity.CENTER }
        box.addView(sub, lp(0,38))

        val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,22,22,22); background=bg(0xE6141B25.toInt(), 28f) }
        status = TextView(this).apply { text="● SYSTEM READY"; textSize=15f; setTextColor(Color.rgb(80,235,255)); gravity=Gravity.CENTER }
        card.addView(status, lp(0,45))
        val info = TextView(this).apply { text="Board scan → FEN → engine analysis\nCamera mode supports a physical/offline board.\nScreen mode is intended for your own offline/self-game analysis."; textSize=13f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER }
        card.addView(info, lp(0,78))
        box.addView(card, lp(0,170))

        val sideTitle = TextView(this).apply { text="SIDE TO MOVE"; textSize=12f; setTextColor(Color.GRAY); setPadding(4,22,4,8) }
        box.addView(sideTitle)
        val sides = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val white = button("WHITE") { selectedSide="WHITE"; selectSide(white, black) }
        val black = button("BLACK") { selectedSide="BLACK"; selectSide(black, white) }
        sides.addView(white, LinearLayout.LayoutParams(0,58,1f).apply { marginEnd=8 })
        sides.addView(black, LinearLayout.LayoutParams(0,58,1f).apply { marginStart=8 })
        box.addView(sides)
        selectSide(white, black)

        val start = button("START SCREEN ANALYSIS") { requestOverlayThenCapture() }
        box.addView(start, lp(0,64).apply { topMargin=18 })
        val camera = button("OPEN PHYSICAL BOARD CAMERA") { startActivity(Intent(this, CameraActivity::class.java).putExtra("SIDE", selectedSide)) }
        box.addView(camera, lp(0,64).apply { topMargin=10 })
        val stop = button("STOP ANALYZER") { stopService(Intent(this, LiveOverlayService::class.java)); status.text="● ANALYZER STOPPED" }
        box.addView(stop, lp(0,60).apply { topMargin=10 })

        val manual = TextView(this).apply { text="MANUAL FEN / PUZZLE MODE\nUse the floating panel after launch to paste a FEN or inspect saved positions."; textSize=12f; setTextColor(Color.GRAY); gravity=Gravity.CENTER; setPadding(10,25,10,5) }
        box.addView(manual, lp(0,65))
        setContentView(root)
    }

    private fun requestOverlayThenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this,"Allow Keshri Hax to display over other apps, then press Start again.",Toast.LENGTH_LONG).show(); return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun selectSide(a: Button, b: Button) { a.alpha=1f; b.alpha=.55f }
    private fun button(text:String, action:()->Unit)=Button(this).apply { this.text=text; textSize=12f; setTextColor(Color.WHITE); background=bg(0xE61A2530.toInt(),22f); setOnClickListener{action()} }
    private fun bg(color:Int,r:Float)=GradientDrawable().apply{setColor(color);cornerRadius=r}
    private fun lp(weight:Int,h:Int)=LinearLayout.LayoutParams(-1,h).apply{if(weight>0)this.weight=weight}
}
