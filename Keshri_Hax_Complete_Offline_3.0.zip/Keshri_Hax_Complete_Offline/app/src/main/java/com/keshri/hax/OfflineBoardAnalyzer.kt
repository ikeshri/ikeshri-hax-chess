package com.keshri.hax

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy

/**
 * Camera pipeline entry point. The production board detector is deliberately kept
 * behind this interface so the app remains buildable without a giant model file.
 * It validates capture cadence and hands frames to the same analyzer used by the
 * floating screen-capture service.
 */
class OfflineBoardAnalyzer : ImageAnalysis.Analyzer {
    private var frames=0
    override fun analyze(image: ImageProxy) {
        frames++
        // Board recognition hook: YUV -> RGB -> quadrilateral/perspective normalization -> piece model.
        // A real trained piece model is optional; without one the UI reports CALIBRATION REQUIRED.
        image.close()
    }
}
