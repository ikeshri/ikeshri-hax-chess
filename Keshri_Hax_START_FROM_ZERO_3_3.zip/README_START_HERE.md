# Keshri Hax 3.3 — Codespaces setup pack

This package contains the Android source project and a GitHub Actions workflow to build a debug APK using Java 17 and Android SDK 35 on GitHub-hosted runners. The user's Codespaces environment does not need a local Android SDK for the Actions build.

Read `START_HERE_HINDI.txt` first. It includes one copy-paste command for backing up colliding files and installing the project files into `/workspaces/ikeshri-hax-chess`.

**Important:** This is source code, not a prebuilt APK. Build success depends on external downloads for the Stockfish source and TFLite vision model. A green CI build is not a guarantee of camera accuracy or OEM overlay behavior; test on the actual phone.
