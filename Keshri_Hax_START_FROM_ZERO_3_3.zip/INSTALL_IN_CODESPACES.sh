#!/usr/bin/env bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "$0")/project" && pwd)"
TARGET_DIR="${1:-$PWD}"
TARGET_DIR="$(mkdir -p "$TARGET_DIR" && cd "$TARGET_DIR" && pwd)"
if [[ ! -f "$SOURCE_DIR/settings.gradle.kts" || ! -f "$SOURCE_DIR/app/build.gradle.kts" ]]; then
  echo "ERROR: ZIP package is incomplete: Android project files are missing." >&2
  exit 2
fi
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$TARGET_DIR/.keshri-hax-backup-$STAMP"
mkdir -p "$BACKUP"
while IFS= read -r -d '' item; do
  rel="${item#"$SOURCE_DIR"/}"
  if [[ -e "$TARGET_DIR/$rel" ]]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -a "$TARGET_DIR/$rel" "$BACKUP/$rel"
  fi
done < <(find "$SOURCE_DIR" -mindepth 1 -print0)
cp -a "$SOURCE_DIR/." "$TARGET_DIR/"
echo "Project files copied to: $TARGET_DIR"
echo "Existing colliding files backed up at: $BACKUP"
echo "Java/Android SDK are not installed by this script; GitHub Actions provisions them for the APK build."
echo "Next: commit/push the files, then GitHub repo -> Actions -> Build Keshri Hax APK -> Run workflow."
